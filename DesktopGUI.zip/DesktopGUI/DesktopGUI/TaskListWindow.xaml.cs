using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;

namespace DesktopGUI
{
    public partial class TaskListWindow : Window
    {
        public ObservableCollection<string> Tasks { get; } = new ObservableCollection<string>();

        public TaskListWindow()
        {
            InitializeComponent();
            TasksListBox.ItemsSource = Tasks;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            AddTaskFromTextBox();
        }

        private void NewTaskTextBox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                AddTaskFromTextBox();
                e.Handled = true;
            }
        }

        private void AddTaskFromTextBox()
        {
            var text = NewTaskTextBox.Text?.Trim();
            if (!string.IsNullOrEmpty(text))
            {
                Tasks.Add(text);
                NewTaskTextBox.Clear();
            }
        }

        private void RemoveSelectedButton_Click(object sender, RoutedEventArgs e)
        {
            var selected = TasksListBox.SelectedItems;
            // Need to copy because we'll modify the collection
            var toRemove = new string[selected.Count];
            selected.CopyTo(toRemove, 0);
            foreach (var item in toRemove)
            {
                Tasks.Remove(item);
            }
        }
    }
}