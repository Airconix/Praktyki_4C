using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace DesktopGUI
{
    public partial class RegistrationWindow : Window
    {
        public RegistrationWindow()
        {
            InitializeComponent();
        }

        private void SetError(System.Windows.Controls.Control control, System.Windows.Controls.TextBlock errorBlock, string message)
        {
            if (string.IsNullOrEmpty(message))
            {
                control.ClearValue(BorderBrushProperty);
                control.ClearValue(BorderThicknessProperty);
                errorBlock.Text = "";
            }
            else
            {
                control.BorderBrush = System.Windows.Media.Brushes.Red;
                control.BorderThickness = new Thickness(1.5);
                errorBlock.Text = message;
            }
        }

        private void FirstNameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var txt = FirstNameTextBox.Text?.Trim();
            SetError(FirstNameTextBox, FirstNameError, string.IsNullOrEmpty(txt) ? "Imie wymagane" : "");
        }

        private void LastNameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var txt = LastNameTextBox.Text?.Trim();
            SetError(LastNameTextBox, LastNameError, string.IsNullOrEmpty(txt) ? "Nazwisko wymagane" : "");
        }

        private void EmailTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var txt = EmailTextBox.Text?.Trim();
            if (string.IsNullOrEmpty(txt))
            {
                SetError(EmailTextBox, EmailError, "Email wymagany");
                return;
            }

            var ok = Regex.IsMatch(txt, @"^[^@\s]+@[^@\s]+\.[^@\s]+$");
            SetError(EmailTextBox, EmailError, ok ? "" : "Nieprawidlowy email");
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            ValidatePasswords();
        }

        private void ConfirmPasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            ValidatePasswords();
        }

        private void ValidatePasswords()
        {
            var p = PasswordBox.Password ?? "";
            var c = ConfirmPasswordBox.Password ?? "";

            if (string.IsNullOrEmpty(p) || p.Length < 6)
            {
                SetError(PasswordBox, PasswordError, "Haslo min. 6 znakow");
            }
            else
            {
                SetError(PasswordBox, PasswordError, "");
            }

            if (p != c)
            {
                SetError(ConfirmPasswordBox, ConfirmPasswordError, "Hasla nie sa zgodne");
            }
            else
            {
                SetError(ConfirmPasswordBox, ConfirmPasswordError, "");
            }
        }

        private void TermsCheckBox_Changed(object sender, RoutedEventArgs e)
        {
            SetError(TermsCheckBox, TermsError, TermsCheckBox.IsChecked == true ? "" : "Musisz zaakceptowac regulamin");
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            // Trigger validations
            FirstNameTextBox_TextChanged(null, null);
            LastNameTextBox_TextChanged(null, null);
            EmailTextBox_TextChanged(null, null);
            ValidatePasswords();
            TermsCheckBox_Changed(null, null);

            var hasError = !string.IsNullOrEmpty(FirstNameError.Text) || !string.IsNullOrEmpty(LastNameError.Text) || !string.IsNullOrEmpty(EmailError.Text) || !string.IsNullOrEmpty(PasswordError.Text) || !string.IsNullOrEmpty(ConfirmPasswordError.Text) || !string.IsNullOrEmpty(TermsError.Text);

            if (hasError)
            {
                System.Windows.MessageBox.Show("Popraw formularz", "Blad", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            System.Windows.MessageBox.Show("Zarejestrowano pomyslnie", "Sukces", MessageBoxButton.OK, MessageBoxImage.Information);
            this.Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}