using System.Windows;

namespace DesktopGUI
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void OpenCalculator_Click(object sender, RoutedEventArgs e)
        {
            var w = new CalculatorWindow();
            w.Show();
        }

        private void OpenClock_Click(object sender, RoutedEventArgs e)
        {
            var w = new AnalogClockWindow();
            w.Show();
        }

        private void OpenNotepad_Click(object sender, RoutedEventArgs e)
        {
            var w = new NotepadWindow();
            w.Show();
        }

        private void OpenGallery_Click(object sender, RoutedEventArgs e)
        {
            var w = new ImageGalleryWindow();
            w.Show();
        }

        private void OpenConverter_Click(object sender, RoutedEventArgs e)
        {
            var w = new UnitConverterWindow();
            w.Show();
        }

        private void OpenTasks_Click(object sender, RoutedEventArgs e)
        {
            var w = new TaskListWindow();
            w.Show();
        }

        private void OpenRegistration_Click(object sender, RoutedEventArgs e)
        {
            var w = new RegistrationWindow();
            w.Show();
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}