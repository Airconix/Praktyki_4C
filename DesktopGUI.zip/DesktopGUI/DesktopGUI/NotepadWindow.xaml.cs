using Microsoft.Win32;
using System.IO;
using System.Windows;

namespace DesktopGUI
{
    public partial class NotepadWindow : Window
    {
        private string? _currentFilePath;
        private bool _isDirty = false;

        public NotepadWindow()
        {
            InitializeComponent();
        }

        private void NewFile_Click(object sender, RoutedEventArgs e)
        {
            if (ConfirmDiscardChanges())
            {
                Editor.Clear();
                _currentFilePath = null;
                _isDirty = false;
                UpdateTitle();
            }
        }

        private void OpenFile_Click(object sender, RoutedEventArgs e)
        {
            if (!ConfirmDiscardChanges()) return;

            var dlg = new Microsoft.Win32.OpenFileDialog { Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*" };
            if (dlg.ShowDialog() == true)
            {
                Editor.Text = File.ReadAllText(dlg.FileName);
                _currentFilePath = dlg.FileName;
                _isDirty = false;
                UpdateTitle();
            }
        }

        private void SaveFile_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(_currentFilePath))
            {
                SaveAsFile_Click(sender, e);
                return;
            }

            File.WriteAllText(_currentFilePath, Editor.Text);
            _isDirty = false;
            UpdateTitle();
        }

        private void SaveAsFile_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new Microsoft.Win32.SaveFileDialog { Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*" };
            if (dlg.ShowDialog() == true)
            {
                File.WriteAllText(dlg.FileName, Editor.Text);
                _currentFilePath = dlg.FileName;
                _isDirty = false;
                UpdateTitle();
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private bool ConfirmDiscardChanges()
        {
            if (!_isDirty) return true;
            var res = System.Windows.MessageBox.Show("Zapisa� zmiany?", "Niezapisane zmiany", MessageBoxButton.YesNoCancel, MessageBoxImage.Warning);
            if (res == MessageBoxResult.Cancel) return false;
            if (res == MessageBoxResult.Yes)
            {
                SaveFile_Click(null, null);
                return !_isDirty; // if save succeeded, isDirty false
            }
            return true; // No = discard
        }

        private void Editor_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            _isDirty = true;
            UpdateTitle();
        }

        private void UpdateTitle()
        {
            Title = (_currentFilePath == null ? "Untitled" : Path.GetFileName(_currentFilePath)) + (_isDirty ? " *" : "") + " - Mini Notatnik";
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!ConfirmDiscardChanges()) e.Cancel = true;
        }
    }
}