using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;

namespace DesktopGUI
{
    public partial class UnitConverterWindow : Window
    {
        public UnitConverterWindow()
        {
            InitializeComponent();
            this.Loaded += UnitConverterWindow_Loaded;
        }

        private void UnitConverterWindow_Loaded(object? sender, RoutedEventArgs e)
        {
            // Ensure controls exist (guard against XAML loading issues)
            if (InputTextBox != null)
                InputTextBox.Text = string.Empty;
            if (ResultTextBox != null)
                ResultTextBox.Text = string.Empty;

            // Ensure a conversion is selected
            if (ConversionComboBox != null && ConversionComboBox.SelectedIndex < 0 && ConversionComboBox.Items.Count > 0)
                ConversionComboBox.SelectedIndex = 0;

            // perform initial calculation if possible
            try { Recalculate(); } catch { /* swallow to avoid crash on startup */ }
        }

        private void ConversionComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Recalculate();
        }

        private void InputTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Recalculate();
        }

        private void Recalculate()
        {
            // guard: if controls are not yet initialized, skip
            if (InputTextBox == null || ResultTextBox == null || ConversionComboBox == null)
                return;

            if (string.IsNullOrWhiteSpace(InputTextBox.Text))
            {
                ResultTextBox.Text = string.Empty;
                return;
            }

            // Try parse using current culture first (handles comma as decimal separator), then fallback to invariant
            if (!double.TryParse(InputTextBox.Text, NumberStyles.Float, CultureInfo.CurrentCulture, out var value))
            {
                if (!double.TryParse(InputTextBox.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out value))
                {
                    ResultTextBox.Text = "Invalid";
                    return;
                }
            }

            var idx = ConversionComboBox.SelectedIndex;
            if (idx < 0) idx = 0;
            double result;
            string suffix;

            switch (idx)
            {
                case 0: // km -> mile
                    result = value * 0.621371;
                    suffix = "mi";
                    break;
                case 1: // mile -> km
                    result = value / 0.621371;
                    suffix = "km";
                    break;
                case 2: // kg -> lb
                    result = value * 2.20462;
                    suffix = "lb";
                    break;
                case 3: // lb -> kg
                    result = value / 2.20462;
                    suffix = "kg";
                    break;
                case 4: // C -> F
                    result = (value * 9.0 / 5.0) + 32.0;
                    suffix = "�F";
                    break;
                case 5: // F -> C
                    result = (value - 32.0) * 5.0 / 9.0;
                    suffix = "�C";
                    break;
                default:
                    ResultTextBox.Text = "";
                    return;
            }

            // Format result using current culture and sensible number of decimals depending on unit
            string formatted;
            if (suffix == "�F" || suffix == "�C")
            {
                // temperatures: show one decimal
                formatted = result.ToString("F1", CultureInfo.CurrentCulture);
            }
            else
            {
                // other units: show up to 4 decimal places, trim trailing zeros
                formatted = result.ToString("F4", CultureInfo.CurrentCulture).TrimEnd('0').TrimEnd(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator.ToCharArray());
                if (string.IsNullOrEmpty(formatted)) formatted = "0";
            }

            ResultTextBox.Text = $"{formatted} {suffix}";
        }
    }
}