using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Imaging;

namespace DesktopGUI
{
    public class ImageItem
    {
        public string Path { get; set; } = "";
        public string Name { get; set; } = "";
        public BitmapImage Thumbnail { get; set; } = new BitmapImage();
    }

    public partial class ImageGalleryWindow : Window
    {
        public ObservableCollection<ImageItem> Images { get; } = new ObservableCollection<ImageItem>();

        public ImageGalleryWindow()
        {
            InitializeComponent();
            ThumbnailsListBox.ItemsSource = Images;
        }

        private async void ChooseFolderButton_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new System.Windows.Forms.FolderBrowserDialog();
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                FolderPathText.Text = dlg.SelectedPath;
                await LoadImagesFromFolderAsync(dlg.SelectedPath);
            }
        }

        private async Task LoadImagesFromFolderAsync(string folder)
        {
            Images.Clear();
            var extensions = new[] { ".jpg", ".jpeg", ".png", ".bmp", ".gif" };
            var files = Directory.EnumerateFiles(folder).Where(f => extensions.Contains(Path.GetExtension(f).ToLowerInvariant()));

            foreach (var f in files)
            {
                var item = new ImageItem { Path = f, Name = Path.GetFileName(f) };
                item.Thumbnail = await Task.Run(() => CreateThumbnail(f, 240, 140));
                Images.Add(item);
            }
        }

        private BitmapImage CreateThumbnail(string path, int width, int height)
        {
            var img = new BitmapImage();
            img.BeginInit();
            img.CacheOption = BitmapCacheOption.OnLoad;
            img.UriSource = new System.Uri(path);
            img.DecodePixelWidth = width;
            img.DecodePixelHeight = height;
            img.EndInit();
            img.Freeze();
            return img;
        }

        private void ThumbnailsListBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (ThumbnailsListBox.SelectedItem is ImageItem ii)
            {
                var img = new BitmapImage();
                img.BeginInit();
                img.CacheOption = BitmapCacheOption.OnLoad;
                img.UriSource = new System.Uri(ii.Path);
                img.EndInit();
                PreviewImage.Source = img;
            }
            else
            {
                PreviewImage.Source = null;
            }
        }
    }
}