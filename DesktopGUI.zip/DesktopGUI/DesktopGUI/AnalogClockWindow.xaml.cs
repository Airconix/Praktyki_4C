using System;
using System.Windows;
using System.Windows.Threading;

namespace DesktopGUI
{
    public partial class AnalogClockWindow : Window
    {
        private readonly DispatcherTimer _timer;

        public AnalogClockWindow()
        {
            InitializeComponent();

            _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(200) };
            _timer.Tick += Timer_Tick;
            _timer.Start();
        }

        private void Timer_Tick(object? sender, EventArgs e)
        {
            var now = DateTime.Now;
            DigitalDisplay.Text = now.ToString("HH:mm:ss");

            double secondAngle = now.Second * 6.0 + now.Millisecond * 0.006;
            double minuteAngle = now.Minute * 6.0 + now.Second * 0.1;
            double hourAngle = (now.Hour % 12) * 30.0 + now.Minute * 0.5;

            ((System.Windows.Media.RotateTransform)SecondHand.RenderTransform).Angle = secondAngle;
            ((System.Windows.Media.RotateTransform)MinuteHand.RenderTransform).Angle = minuteAngle;
            ((System.Windows.Media.RotateTransform)HourHand.RenderTransform).Angle = hourAngle;
        }
    }
}