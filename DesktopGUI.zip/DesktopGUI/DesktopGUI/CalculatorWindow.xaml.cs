using System.Globalization;
using System.Windows;
using System.Windows.Controls;

namespace DesktopGUI
{
    public partial class CalculatorWindow : Window
    {
        private double _accumulator = 0;
        private string? _operator = null;
        private bool _isNewEntry = true;
        private bool _hasDot = false;

        public CalculatorWindow()
        {
            InitializeComponent();
        }

        private void NumberButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn)
            {
                string digit = btn.Content.ToString();
                if (Display.Text == "0" || _isNewEntry)
                {
                    Display.Text = digit;
                    _isNewEntry = false;
                }
                else
                {
                    Display.Text += digit;
                }
            }
        }

        private void DotButton_Click(object sender, RoutedEventArgs e)
        {
            var dec = CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator;
            if (!_hasDot)
            {
                if (_isNewEntry || string.IsNullOrEmpty(Display.Text))
                {
                    Display.Text = "0" + dec;
                    _isNewEntry = false;
                }
                else
                {
                    // prevent adding if already contains separator
                    if (!Display.Text.Contains(dec))
                        Display.Text += dec;
                }
                _hasDot = Display.Text.Contains(dec);
            }
        }

        private void OperatorButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn)
            {
                string op = btn.Content.ToString();

                if (!_isNewEntry)
                {
                    CalculateCurrent();
                }

                _operator = op;
                _accumulator = double.TryParse(Display.Text, NumberStyles.Float, CultureInfo.CurrentCulture, out var v) ? v : 0;
                _isNewEntry = true;
                _hasDot = false;
            }
        }

        private void EqualsButton_Click(object sender, RoutedEventArgs e)
        {
            CalculateCurrent();
            _operator = null;
            _isNewEntry = true;
            var dec = CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator;
            _hasDot = Display.Text.Contains(dec);
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            Display.Text = "0";
            _accumulator = 0;
            _operator = null;
            _isNewEntry = true;
            _hasDot = false;
        }

        private void CalculateCurrent()
        {
            double current = double.TryParse(Display.Text, NumberStyles.Float, CultureInfo.CurrentCulture, out var v) ? v : 0;

            if (string.IsNullOrEmpty(_operator))
            {
                _accumulator = current;
                Display.Text = _accumulator.ToString();
                return;
            }

            try
            {
                double result = _operator switch
                {
                    "+" => _accumulator + current,
                    "-" => _accumulator - current,
                    "*" => _accumulator * current,
                    "/" => current == 0 ? double.NaN : _accumulator / current,
                    _ => current
                };

                Display.Text = double.IsNaN(result) ? "Error" : result.ToString(CultureInfo.CurrentCulture);
                _accumulator = result;
            }
            catch
            {
                Display.Text = "Error";
                _accumulator = 0;
            }
        }
    }
}